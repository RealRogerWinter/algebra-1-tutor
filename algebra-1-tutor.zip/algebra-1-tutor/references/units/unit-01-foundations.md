# Unit 1: Foundations & the Language of Algebra

> **Prerequisites:** Arithmetic only (add, subtract, multiply, divide whole numbers; basic fractions and decimals).
> **By the end, the student can:**
> - Read \(=\) as "the same as" (a balance), and judge whether a number sentence is true, false, or open.
> - Solve simple one-step equations by inspection and by undoing.
> - Name the kinds of numbers (natural, whole, integer, rational, decimal) and place them on the number line; recognize that a number's *value*, not its *spelling*, fixes its type.
> - Apply order of operations as four tiers (P, E, [MD], [AS]), working left to right within a tier.
> - Add, subtract, multiply, and divide negative numbers fluently, with the sign rules.
> - Tell an *expression* from an *equation*, and evaluate an expression by substitution.

## Teaching this unit (orientation for the tutor)

This unit builds the *language* the rest of the course speaks. The arc: first re-wire what \(=\) means (1.1), then map the terrain of numbers so later answers like \(3.5\) or \(-5\) feel normal (1.2), then nail the two procedural skills everything rests on — order of operations (1.3) and signed arithmetic (1.4) — and finally separate the two central objects, *expressions* and *equations* (1.5).

The single highest-leverage moment is 1.1: the **relational meaning of the equals sign** (see `misconceptions.md` §1). Front-load it and keep testing it with non-standard sentences (\(7 = 4+3\), \(\square + 3 = 5 + 7\)) all unit long — every solving move later depends on it. The other big traps: same-tier left-to-right in order of operations (`misconceptions.md` §5), and the cluster of negative-number errors, especially subtracting a negative and ordering negatives (`misconceptions.md` §3).

Pacing: a fluent adult may blow through 1.2–1.4 — let them; reserve the full concrete→pictorial→symbolic ceremony (`pedagogy.md`) for whatever actually snags. Thread a light **function preview**: an equation or rule turns an input into an output; we will *name* that idea (functions) in Unit 4. Use the mystery-box / reserved-seat variable metaphors (`metaphors.md`) and the money/number-line metaphors for negatives. Model the habit of **substituting an answer back to check** from day one — it self-catches most sign and order errors.

---

## Lesson 1.1: Variables and the meaning of equations

**Goal:** Read \(=\) as a balance ("the same as"), use a variable as a stand-in for an unknown number, and solve one-step equations by inspection and by undoing.
**Why it matters:** This is the most predictive idea in the whole course. Every equation-solving move — "do the same to both sides" — only makes sense if \(=\) means *balance*, not *compute the answer here*.

**New terms:**
- **Variable:** a letter that stands in for a number we don't know yet (not a label for an object). Every copy of the same letter in one problem holds the *same* hidden number.
- **Equation:** a sentence claiming two things have the *same value*, joined by \(=\).
- **Open sentence:** a number sentence with a blank or variable — neither true nor false until the unknown is filled (e.g. \(x + 3 = 7\)).

**Teaching arc (concrete → pictorial → symbolic):**
1. **Front-load the key idea.** Say it plainly: "\(=\) means *the same as* — the two sides balance. It is **not** a button that says 'the answer goes here.'" This reframe is the whole lesson (see `misconceptions.md` §1).
2. **Concrete (balance scale).** Use the balance-scale metaphor (`metaphors.md`, Equations A). Left pan holds \(8+4\); the right pan must weigh the same. For \(\square + 5\) to balance \(8+4=12\), the box must hold \(7\). Whatever you do to one pan, do to the other to stay level.
3. **True / false / open sorting.** Have them judge sentences written in *non-standard* forms — this is where the operational misread surfaces:
   - \(7 = 4 + 3\) → **true** (don't let "it's backwards" throw them).
   - \(8 = 8\) → **true** (nothing to "do" — and that's fine).
   - \(5 + 2 = 9\) → **false**.
   - \(\square + 3 = 5 + 7\) → **open**; fill the blank so it *stays true* (right side is \(12\), so \(\square = 9\)).
4. **Variable as a box.** Reframe "\(3 + ? = 7\)" as "\(3 + x = 7\)": the \(x\) is a closed box; what number inside keeps the balance? Use the mystery-box / reserved-seat metaphor (`metaphors.md`, Variables).
5. **Symbolic — two roads to the same answer.** Solve \(x + 3 = 7\):
   - *By inspection:* "what plus 3 is 7?" → \(4\).
   - *By undoing:* the 3 is added on, so undo it by subtracting 3 from **both** sides: \(x + 3 - 3 = 7 - 3 \Rightarrow x = 4\). Check: \(4 + 3 = 7\).
6. **Function preview (light).** "Notice the rule '\(\,+3\,)' turns an input into an output: feed in 4, out comes 7. An equation pins the output and asks for the input. We'll give that input→output idea a name later — it's called a *function*."

**Worked examples:**

1. Fill the blank so it stays true: \(8 + 4 = \square + 5\). Left side \(= 12\); need \(\square + 5 = 12\), so \(\square = 7\). *(Filling 9 or 17 is the "compute here" misread — see Watch for.)*
2. True, false, or open? \(7 = 4 + 3\). Both sides equal \(7\) — **true**.
3. Solve by undoing: \(x + 3 = 7\). Subtract 3 from both sides: \(x = 4\). Check: \(4+3=7\).
4. Solve by undoing: \(2x = 10\). The \(x\) is multiplied by 2; undo by dividing both sides by 2: \(x = 5\). Check: \(2(5)=10\).
5. Solve: \(\dfrac{x}{3} = 4\). The \(x\) is divided by 3; undo by multiplying both sides by 3: \(x = 12\). Check: \(12/3 = 4\).

**Watch for:** The operational view of \(=\) (`misconceptions.md` §1). *Tell:* fills \(8 + 4 = \square + 5\) with **9** (computed \(8+4\), ignored the \(+5\)) or **17** (added everything). *Repair:* go back to the balance scale and ask what the right pan must weigh — don't just restate the rule. Also watch the letter-as-object error (`misconceptions.md` §2): \(x\) is a *number we don't know*, not "apples."

**Visuals to offer:** A simple balance-scale sketch in words usually suffices; no artifact required. A number line can wait for 1.2.

**Check for understanding (transfer):**
- "Fill the blank so it stays true: \(\,6 + \square = 4 + 5\). Walk me through how you know."
- "Is \(9 = 9\) a real equation? Why or why not?"
- "In \(x - 2 = 5\), which operation do we undo, and why does undoing it tell us \(x\)?"

**Practice problems:**

*Judge true / false / open (write which):*
1. \(6 = 2 + 4\)
2. \(3 + 5 = 9\)
3. \(\square + 2 = 6\)

*Fill the blank so the sentence stays true:*
4. \(8 + 4 = \square + 5\)
5. \(10 = \square + 3\)

*Solve by inspection or by undoing (show the undo step):*
6. \(x + 3 = 7\)
7. \(x + 4 = 9\)
8. \(x - 2 = 5\)
9. \(2x = 10\)
10. \(\dfrac{x}{3} = 4\)
11. \(5 + x = 12\)
12. \(x - 6 = 0\)
13. \(4x = 20\)

**Answer key:**
1. true 2. false 3. open (true when the blank is \(4\)) 4. \(7\) 5. \(7\) 6. \(x=4\) 7. \(x=5\) 8. \(x=7\) 9. \(x=5\) 10. \(x=12\) 11. \(x=7\) 12. \(x=6\) 13. \(x=5\)

---

## Lesson 1.2: The number system & the number line

**Goal:** Build a layered map of the kinds of numbers and place them on one number line, so later non-integer and negative answers feel normal, not like mistakes.
**Why it matters:** When a student solves \(2x = 7\) and gets \(3.5\), they need to *trust* that \(3.5\) is a real, correct number — not assume they erred. The number line is the unifying picture for the whole course; algebra lives on the *whole* line.

**New terms:**
- **Natural (counting) numbers:** \(1, 2, 3, \dots\)
- **Whole numbers:** the naturals plus \(0\).
- **Integers:** whole numbers and their negatives — \(\dots, -2, -1, 0, 1, 2, \dots\) — no fractional part.
- **Rational numbers:** any number that can be written as a ratio of two integers \(\tfrac{a}{b}\) (\(b \ne 0\)). This *includes* integers (\(5 = \tfrac{5}{1}\)), terminating decimals (\(4.8 = \tfrac{24}{5}\)), and repeating decimals (\(0.333\ldots = \tfrac{1}{3}\)).
- **Decimal:** a way of *writing* a number using a decimal point; the way it's written doesn't change what kind of number it is.

**Teaching arc (concrete → pictorial → symbolic):**
1. **Layers, like nested boxes.** Start at counting numbers and add one capability at a time: add \(0\) → whole numbers; add negatives → integers; allow ratios → rationals. Each layer *contains* the previous one (every integer is rational).
2. **The number line is the map.** Draw it: integers as evenly spaced ticks, with \(0\) in the middle and negatives to the left. Then the key picture: **between any two integers there are infinitely many numbers** — \(\tfrac34\), \(2.5\), \(0.333\ldots\) all live in the gaps. Algebra uses the *whole* line, not just the ticks.
3. **Same value, many spellings.** Show \(5 = \dfrac{5}{1} = 5.0\) — one point on the line, three spellings. This is the crux: a number's *type* is set by its *value*, not by how it's written.
4. **Connect forward.** "When we solve \(2x = 7\) we get \(3.5\). That's not an error — it's a perfectly real point on the line, sitting halfway between 3 and 4." Plant that now so it pays off in Unit 2.

**Worked examples:**

1. Classify \(7\). It's a counting number, so it's an **integer**, and \(7 = \tfrac{7}{1}\) so it's also **rational**.
2. Classify \(4.8\). Not a whole amount, so *not* an integer; but \(4.8 = \tfrac{24}{5}\), a ratio of integers — **rational, a non-integer decimal**.
3. Classify \(\tfrac{10}{2}\). Don't be fooled by the fraction bar: \(\tfrac{10}{2} = 5\). Its *value* is \(5\), so it's an **integer** (and rational). How it's written doesn't fix its type.
4. Classify \(0.333\ldots\). The repeating decimal equals \(\tfrac{1}{3}\), a ratio of integers — **rational, non-integer**. (Again: spelling vs. value.)
5. Show three spellings of one number: \(5 = \dfrac{5}{1} = 5.0\) — all the *same point* on the line.

**Watch for:** The belief that a number written as a fraction "must be a fraction" or that a decimal "can't be an integer." Problems 7 (\(\tfrac{10}{2}=5\)) and 8 (\(0.333\ldots = \tfrac13\)) below are the instructive ones — *evaluate first, then classify*. Also pre-empt the negatives-ordering surprise that's coming in 1.4 ("which is farther left?"). Fraction-magnitude care connects to `misconceptions.md` §4.

**Visuals to offer:** A clean **number line** (`visuals.md` Template 1 for a marked point, or a simple ASCII line) showing integers as ticks with \(\tfrac34\), \(2.5\), and \(-2.5\) placed in the gaps. Always pair with a one-sentence description.

**Check for understanding (transfer):**
- "Give me a number that is rational but *not* an integer, and explain how you know it's rational."
- "Is \(\tfrac{12}{3}\) an integer? Convince me using its value, not its appearance."
- "Roughly where does \(-2.5\) sit relative to \(-2\) and \(-3\) on the line?"

**Practice problems:** Classify each number; label **all** types that apply (integer / rational / non-integer decimal). Evaluate first where needed.
1. \(7\)
2. \(-4\)
3. \(4.8\)
4. \(0\)
5. \(\tfrac{3}{4}\)
6. \(-2.5\)
7. \(\tfrac{10}{2}\)
8. \(0.333\ldots\)

**Answer key:**
1. integer, rational
2. integer, rational
3. rational, non-integer decimal
4. integer, rational
5. rational, non-integer
6. rational, non-integer decimal
7. \(=5\) → integer, rational
8. \(=\tfrac13\) → rational, non-integer

*(7 and 8 are the teaching moments: how a number is written doesn't fix its type — its value does.)*

---

## Lesson 1.3: Order of operations

**Goal:** Evaluate numeric expressions correctly using order of operations as **four tiers** — P, E, [MD], [AS] — working left to right within a tier.
**Why it matters:** A reliable, shared order is what lets everyone agree on what an expression means. Most errors here are *systematic* (not random), so naming the trap fixes them.

**New terms:**
- **Order of operations:** the agreed sequence for evaluating an expression. PEMDAS, but really **four tiers**: **P**arentheses, **E**xponents, **[M**ultiply/**D**ivide**]** (one tier, left to right), **[A**dd/**S**ubtract**]** (one tier, left to right).

**Teaching arc (concrete → pictorial → symbolic):**
1. **Four tiers, not six.** The headline (see `misconceptions.md` §5): multiply and divide are *equal-rank partners*, read left to right; same for add and subtract. There is no "M before D" or "A before S."
2. **Show the traps directly.** Walk each one slowly:
   - \(12 \div 2 \times 3\): left to right, \(12\div2 = 6\), then \(6\times3 = 18\) — **not** \(2\).
   - \(8 - 3 + 2\): left to right, \(8-3 = 5\), then \(5+2 = 7\) — **not** \(3\).
   - \(2 \times 3^2\): the exponent is a *higher* tier, so square first: \(3^2 = 9\), then \(2\times9 = 18\) — **not** \(36\).
3. **Parentheses change the meaning.** Contrast \(2 + 3 \times 4 = 14\) with \((2+3)\times 4 = 20\): same digits, different grouping, different value.

**Worked examples:**

1. \(2 + 3 \times 4\): multiply first → \(2 + 12 = 14\).
2. \((2+3)\times 4\): parentheses first → \(5 \times 4 = 20\).
3. \(8 - 3 + 2\): same tier, left to right → \(5 + 2 = 7\). *(Not 3.)*
4. \(12 \div 2 \times 3\): same tier, left to right → \(6 \times 3 = 18\). *(Not 2.)*
5. \(2 + 3^2 \times 2\): exponent → \(2 + 9\times 2\); then multiply → \(2 + 18 = 20\).
6. \(10 - 2 \times (3+1)\): parentheses → \(10 - 2\times 4\); multiply → \(10 - 8 = 2\).

**Watch for:** `misconceptions.md` §5. *Tells:* \(8-3+2 = 3\) (added before subtracting), \(12\div2\times3 = 2\) (multiplied before dividing), \(2\times3^2 = 36\) (multiplied before squaring). *Repair:* "Reading left to right, which of these two equal-rank operations comes first?" — re-anchor on the four-tier picture, don't just re-recite PEMDAS.

**Visuals to offer:** None needed; the tier list and worked traps carry it.

**Check for understanding (transfer):**
- "Without computing fully — in \(20 \div 4 \times 2\), which operation happens first and why?"
- "Why does \(2 \times 3^2\) come out to 18, not 36?"
- "Put parentheses into \(2 + 3 \times 4\) to make it equal 20."

**Practice problems:**
1. \(5 + 2 \times 3\)
2. \((5 + 2)\times 3\)
3. \(10 - 4 + 1\)
4. \(20 \div 4 \times 2\)
5. \(3 + 4^2\)
6. \(2 \times 3^2\)
7. \((6 - 2)^2\)
8. \(18 \div 3 + 3\)
9. \(2 + 2 \times (5 - 3)\)
10. \(30 \div 5 \div 2\)
11. \(4 + 3 \times 2 - 1\)
12. \((8 - 3)\times 2 + 4^2\)

**Answer key:**
1. \(11\) 2. \(21\) 3. \(7\) 4. \(10\) 5. \(19\) 6. \(18\) 7. \(16\) 8. \(9\) 9. \(6\) 10. \(3\) 11. \(9\) 12. \(26\)

*(3, 4, and 10 test left-to-right within a tier; 6 tests square-before-multiply; 12 combines all four tiers.)*

---

## Lesson 1.4: Negative numbers

**Goal:** Add, subtract, multiply, and divide negative numbers fluently, including ordering them and the sign rules.
**Why it matters:** Negatives appear in nearly every later answer. Making them automatic now means a future problem adds only *one* new difficulty, not two.

**New terms:**
- **Opposite (additive inverse):** the same distance from 0 on the other side; the opposite of \(5\) is \(-5\). Subtracting a number is the same as adding its opposite.
- **Sign rules (×, ÷):** same signs → positive; different signs → negative. In a product, an **even** number of negative factors → positive; an **odd** number → negative.

**Teaching arc (concrete → pictorial → symbolic):**
1. **Order on the number line.** Bigger negative = farther *left*. So \(-5 < -2\) (a common surprise — \(5 > 2\) tempts the eye). Money framing (`metaphors.md`, Negatives A): owing \$5 is worse off than owing \$2, so \(-5 < -2\).
2. **Add = walk the line.** Add a positive → move right; add a negative → move left (`metaphors.md`, Negatives B; `pedagogy.md` \(-2+5\) script). \(-3 + (-5)\): start at \(-3\), move 5 more left → \(-8\).
3. **Subtract = add the opposite.** \(5 - 8 = 5 + (-8) = -3\). And the slow, explicit one (see `misconceptions.md` §3): **subtracting a negative is adding** — \(3 - (-4) = 3 + 4 = 7\). Use the "two about-faces" or "a debt forgiven makes you richer" framing; do it deliberately, one negative at a time.
4. **Multiply/divide — count the negatives.** Same signs → positive, different → negative: \((-6)(3) = -18\), \((-6)(-3) = 18\), \(-20 \div 4 = -5\), \(-20 \div (-5) = 4\). For chains, count negatives: even → positive, odd → negative.
5. **Separate the two minus signs out loud** — the *operation* sign vs. the *number's* sign — and substitute to check.

**Worked examples:**

1. \(-3 + (-5) = -8\) (two debts pile up; or start at \(-3\), move 5 left).
2. \(4 + (-9) = -5\) (start at 4, move 9 left).
3. \(5 - 8 = 5 + (-8) = -3\) (subtract = add the opposite).
4. \(3 - (-4) = 3 + 4 = 7\) (subtracting a negative *adds*; two about-faces — slow this down).
5. \((-6)(3) = -18\) (different signs → negative).
6. \((-6)(-3) = 18\) (same signs → positive).
7. \(-20 \div 4 = -5\) (different signs → negative).
8. \(-20 \div (-5) = 4\) (same signs → positive).

**Watch for:** `misconceptions.md` §3 — the negative-number cluster. *Tells:* \(-3 + (-5) = +8\) (applying the multiplication rule to addition), \(6 - (-2) = 4\) (not seeing subtract-a-negative as adding), \(-5 > -2\) (magnitude mistaken for value). *Repair:* switch representation — number line for add/subtract, money/debt for ordering and for subtracting a negative — never just repeat the rule.

**Visuals to offer:** An **ASCII number line** is ideal here (`visuals.md`): show a hop, e.g. start at \(-3\), move 5 left to \(-8\). Pair with a sentence.

**Check for understanding (transfer):**
- "Which is greater, \(-7\) or \(-3\)? Explain using the number line or debt."
- "Rewrite \(6 - (-2)\) as an addition, then evaluate it."
- "\((-2)(-2)(-2)\) — is the result positive or negative *before* you multiply? How do you know?"

**Practice problems:**

*Add / subtract:*
1. \(-4 + (-7)\)
2. \(6 + (-10)\)
3. \(-3 + 8\)
4. \(5 - 9\)
5. \(-2 - 6\)
6. \(4 - (-3)\)
7. \(-7 - (-2)\)
8. \(-10 + 10\)

*Multiply / divide:*
9. \((-5)(4)\)
10. \((-6)(-2)\)
11. \((3)(-7)\)
12. \(-24 \div 6\)
13. \(-18 \div (-3)\)
14. \(15 \div (-5)\)
15. \((-2)(-2)(-2)\)
16. \((-1)(-1)(-1)(-1)\)

**Answer key:**
1. \(-11\) 2. \(-4\) 3. \(5\) 4. \(-4\) 5. \(-8\) 6. \(7\) 7. \(-5\) 8. \(0\) 9. \(-20\) 10. \(12\) 11. \(-21\) 12. \(-4\) 13. \(6\) 14. \(-3\) 15. \(-8\) 16. \(1\)

*(6 and 7 are the subtract-a-negative cases; 15 and 16 are the even/odd-of-negatives chains.)*

---

## Lesson 1.5: Expressions vs. equations; evaluating expressions

**Goal:** Distinguish an *expression* from an *equation*, and evaluate an expression by substituting a value for its variable.
**Why it matters:** These are the two central objects of algebra. An expression *has a value* once you know the variable; an equation *makes a claim*. Confusing them ("solving" an expression, or "evaluating" an equation) derails everything that follows.

**New terms:**
- **Expression:** a mathematical *phrase* with no equals sign — e.g. \(3x + 2\). It names a value once you know the variable; you **evaluate** it.
- **Equation:** a full *sentence* with an \(=\) — e.g. \(3x + 2 = 14\). It *claims* two things are equal; you **solve** it.
- **Evaluate / substitute:** replace the variable with a given number and compute (use the reserved-seat metaphor — the person finally sits down, `metaphors.md`, Variables B).

**Teaching arc (concrete → pictorial → symbolic):**
1. **Phrase vs. sentence.** An expression is a *noun phrase* ("three more than twice a number"); an equation is a full *sentence* with a verb, the \(=\), claiming a balance. The tell is simply: **is there an equals sign?**
2. **Evaluate by substitution.** To evaluate \(3x + 2\) at \(x = 4\): the box \(x\) holds 4, so \(3(4) + 2 = 14\). Then a signed one — evaluate \(5 - 2x\) at \(x = -1\): \(5 - 2(-1) = 5 + 2 = 7\) (callback to 1.4: subtracting a negative). Order of operations (1.3) applies inside every evaluation.
3. **Read the structure (lightly).** Order and grouping matter: \(a - b\) is **not** \(b - a\) (\(5 - 2 \ne 2 - 5\)); and \(2(x+3)\) is **not** \(2x + 3\) — the 2 multiplies *everything* in the parentheses (a preview of the distributive property in Unit 2). Don't formalize yet; just notice it.
4. **Function preview (light).** "Evaluating \(3x+2\) at different inputs is exactly the input→output machine from 1.1: feed in 4, out comes 14. When we name that machine in Unit 4, we'll write it \(f(x) = 3x + 2\) and \(f(4) = 14\)."

**Worked examples:**

1. Expression or equation? \(3x + 2\). No equals sign — it's an **expression**.
2. Expression or equation? \(3x + 2 = 14\). Has an \(=\) — it's an **equation**.
3. Evaluate \(3x + 2\) at \(x = 4\): \(3(4) + 2 = 12 + 2 = 14\).
4. Evaluate \(5 - 2x\) at \(x = -1\): \(5 - 2(-1) = 5 + 2 = 7\). *(Watch the sign — subtracting a negative adds.)*
5. Structure check: evaluate \(2(x+3)\) and \(2x + 3\) at \(x = 3\). \(2(3+3) = 2(6) = 12\), but \(2(3) + 3 = 9\). Different expressions — grouping matters.

**Watch for:** Trying to "solve" an expression (there's nothing to solve — only to evaluate), or dropping a sign when substituting a negative (`misconceptions.md` §3) — keep parentheses around the substituted value: \(5 - 2(-1)\), not \(5 - 2-1\). Also the structure error \(2(x+3) = 2x+3\) (`misconceptions.md` §7) — flag it, formalize in Unit 2.

**Visuals to offer:** None needed. If structure confuses, a quick area-model box for \(2(x+3)\) in LaTeX (`visuals.md`, area-model section) previews distribution.

**Check for understanding (transfer):**
- "Is \(7y\) an expression or an equation? How do you know, and what would you *do* with it?"
- "Evaluate \(4x - 1\) at \(x = 2\), then at \(x = -2\). What changed?"
- "Does \(2(x + 3)\) equal \(2x + 3\)? Test it with \(x = 5\)."

**Practice problems:**

*Identify each as an expression or an equation:*
1. \(3x + 2\)
2. \(3x + 2 = 14\)
3. \(7 - y\)
4. \(5 = 2x - 1\)

*Evaluate each expression at the given value:*
5. \(3x + 2\) at \(x = 4\)
6. \(5 - 2x\) at \(x = -1\)
7. \(2x + 1\) at \(x = 5\)
8. \(4x\) at \(x = -2\)
9. \(3x - 4\) at \(x = -3\)
10. \(10 - 3x\) at \(x = 2\)
11. \(x^2 + 1\) at \(x = -2\)
12. \(2(x + 3)\) at \(x = 3\)

**Answer key:**
1. expression 2. equation 3. expression 4. equation
5. \(14\) 6. \(7\) 7. \(11\) 8. \(-8\) 9. \(-13\) 10. \(4\) 11. \(5\) 12. \(12\)

*(11 previews exponents on a negative — \((-2)^2 = 4\), not \(-4\); 12 reinforces that grouping is not the same as \(2x+3\).)*

---

## Wrap-up & interleaving

**Consolidate:** the relational \(=\) (1.1) is the spine — keep judging non-standard true/false/open sentences in later sessions. The four-tier order of operations (1.3) and signed arithmetic (1.4) are the procedural workhorses; mix them into every future computation. The expression/equation distinction (1.5) sets up *all* of Unit 2.

**Mix back in (interleaving, `pedagogy.md`):** When starting Unit 2's solving, slip in one-step equations that land on a **negative** or **non-integer** answer (callbacks to 1.2 and 1.4) so those stay normal. Use a 60-second order-of-operations or signed-arithmetic warm-up before new material. Always model **substituting the answer back to check** — the self-verification habit seeded here.

**Threading forward:** the input→output preview in 1.1 and 1.5 is the seed of **functions** (Unit 4): "an equation/rule turns an input into an output; we'll name that machine \(f(x)\) later."

**Progress Card should note:** Does the student read \(=\) as balance (not "compute")? Are they fluent with same-tier left-to-right and with negatives (especially subtracting a negative and ordering)? Can they tell an expression from an equation and evaluate by substitution? Flag any of these that are shaky — they're load-bearing for Unit 2.
